package view;

import database.DBConnection;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddNoteForm extends JFrame {

    public AddNoteForm(User user, NotesManagement parent){

        setTitle("Add Note");
        setSize(400,300);
        setLocationRelativeTo(null);

        try{
            String bgUrl = "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80";
            ImageIcon bgIcon = new ImageIcon(new URL(bgUrl));
            Image img = bgIcon.getImage().getScaledInstance(400,300,Image.SCALE_SMOOTH);

            JLabel bg = new JLabel(new ImageIcon(img));
            bg.setLayout(null);
            setContentPane(bg);

            JPanel panel = new JPanel();
            panel.setBounds(20,20,360,240);
            panel.setBackground(new Color(0,0,0,170));
            panel.setLayout(null);
            bg.add(panel);

            JLabel lbl = new JLabel("Add Note");
            lbl.setForeground(Color.WHITE);
            lbl.setFont(new Font("Segoe UI",Font.BOLD,20));
            lbl.setBounds(120,10,200,30);
            panel.add(lbl);
            // Title Label
            JLabel lbl1 = new JLabel("Title");
            lbl1.setForeground(Color.WHITE);
            lbl1.setBounds(30,40,100,20);
            panel.add(lbl1);

// Title Field
            JTextField txtTitle = new JTextField();
            txtTitle.setBounds(30,60,300,30);
            panel.add(txtTitle);

// Content Label
            JLabel lbl2 = new JLabel("Content");
            lbl2.setForeground(Color.WHITE);
            lbl2.setBounds(30,85,100,20);
            panel.add(lbl2);

// Content Area
            JTextArea txtContent = new JTextArea();
            JScrollPane scroll = new JScrollPane(txtContent);
            scroll.setBounds(30,105,300,60);
            panel.add(scroll);

            JButton btnSave = new JButton("Save");
            btnSave.setBounds(50,180,100,30);

            JButton btnCancel = new JButton("Cancel");
            btnCancel.setBounds(200,180,100,30);

            panel.add(btnSave);
            panel.add(btnCancel);

            btnCancel.addActionListener(e -> dispose());

            btnSave.addActionListener(e -> {
                try{
                    Connection con = DBConnection.getConnection();

                    PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO notes(title,content,user_id,created_at) VALUES(?,?,?,NOW())"
                    );

                    ps.setString(1,txtTitle.getText());
                    ps.setString(2,txtContent.getText());
                    ps.setInt(3,user.getUserId());

                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(this,"Saved!");
                    parent.refreshTable();
                    dispose();

                }catch(Exception ex){
                    ex.printStackTrace();
                }
            });

        }catch(Exception e){
            e.printStackTrace();
        }
    }
}