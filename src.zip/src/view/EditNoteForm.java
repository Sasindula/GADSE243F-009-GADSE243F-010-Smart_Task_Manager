package view;

import database.DBConnection;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class EditNoteForm extends JFrame {

    public EditNoteForm(User user, NotesManagement parent,
                        int noteId, String title, String content){

        setTitle("Edit Note");
        setSize(500,400);
        setLocationRelativeTo(null);

        try {
            // Background Image
            String bgUrl = "https://images.unsplash.com/photo-1564866657313-8e891a22f289?auto=format&fit=crop&w=800&q=80";
            ImageIcon bgIcon = new ImageIcon(new java.net.URL(bgUrl));
            Image img = bgIcon.getImage().getScaledInstance(500,400,Image.SCALE_SMOOTH);

            JLabel bg = new JLabel(new ImageIcon(img));
            bg.setLayout(null);
            setContentPane(bg);

            // Glass Panel
            JPanel panel = new JPanel();
            panel.setBounds(40,30,420,320);
            panel.setBackground(new Color(0,0,0,170));
            panel.setLayout(null);
            bg.add(panel);

            // Title Label
            JLabel lblMain = new JLabel("Edit Note");
            lblMain.setFont(new Font("Segoe UI",Font.BOLD,22));
            lblMain.setForeground(Color.WHITE);
            lblMain.setBounds(140,10,200,30);
            panel.add(lblMain);

            // Title Label
            JLabel lblTitle = new JLabel("Title");
            lblTitle.setForeground(Color.WHITE);
            lblTitle.setBounds(20,50,100,25);
            panel.add(lblTitle);

            JTextField txtTitle = new JTextField(title);
            txtTitle.setBounds(20,75,370,30);
            panel.add(txtTitle);

            // Content Label
            JLabel lblContent = new JLabel("Content");
            lblContent.setForeground(Color.WHITE);
            lblContent.setBounds(20,115,100,25);
            panel.add(lblContent);

            JTextArea txtContent = new JTextArea(content);
            JScrollPane scroll = new JScrollPane(txtContent);
            scroll.setBounds(20,140,370,100);
            panel.add(scroll);

            // Buttons
            JButton btnUpdate = new JButton("Update");
            btnUpdate.setBounds(60,260,140,35);
            btnUpdate.setBackground(new Color(46,204,113));
            btnUpdate.setForeground(Color.WHITE);
            btnUpdate.setFocusPainted(false);
            panel.add(btnUpdate);

            JButton btnCancel = new JButton("Cancel");
            btnCancel.setBounds(220,260,140,35);
            btnCancel.setBackground(new Color(231,76,60));
            btnCancel.setForeground(Color.WHITE);
            btnCancel.setFocusPainted(false);
            panel.add(btnCancel);

            btnCancel.addActionListener(e -> dispose());

            // ✅ UPDATE FIXED
            btnUpdate.addActionListener(e -> {
                try(Connection con = DBConnection.getConnection()){

                    PreparedStatement ps = con.prepareStatement(
                            "UPDATE notes SET title=?, content=? WHERE note_id=?"
                    );

                    ps.setString(1, txtTitle.getText());
                    ps.setString(2, txtContent.getText());
                    ps.setInt(3, noteId);

                    int rows = ps.executeUpdate();

                    if(rows > 0){
                        JOptionPane.showMessageDialog(this,"Note updated!");
                        parent.loadNotes(); // refresh table
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(this,"Update failed!");
                    }

                } catch(Exception ex){
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this,"Database Error!");
                }
            });

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}