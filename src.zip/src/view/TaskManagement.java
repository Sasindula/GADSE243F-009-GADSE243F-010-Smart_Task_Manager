package view;

import database.DBConnection;
import model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.*;
import java.util.Date;

public class TaskManagement extends JFrame {

    private User currentUser;
    private JTable taskTable;
    private JTextField txtSearch;

    public TaskManagement(User user){
        this.currentUser = user;

        setTitle("Manage Tasks");
        setSize(850,500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        try{
            // 🌄 Background Image
            String bgUrl = "https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b";
            Image img = new ImageIcon(new URL(bgUrl))
                    .getImage().getScaledInstance(850,500,Image.SCALE_SMOOTH);

            JLabel bg = new JLabel(new ImageIcon(img));
            bg.setLayout(null);
            setContentPane(bg);

            // 🔳 Glass Panel
            JPanel panel = new JPanel();
            panel.setBounds(30,30,780,400);
            panel.setBackground(new Color(0,0,0,170));
            panel.setLayout(null);
            bg.add(panel);

            JLabel title = new JLabel("Task Management");
            title.setForeground(Color.WHITE);
            title.setFont(new Font("Segoe UI",Font.BOLD,26));
            title.setBounds(250,10,300,40);
            panel.add(title);

            // 🔍 Search
            txtSearch = new JTextField();
            txtSearch.setBounds(30,60,400,30);
            panel.add(txtSearch);

            JButton btnSearch = new JButton("Search");
            btnSearch.setBounds(450,60,120,30);
            panel.add(btnSearch);

            // 📋 Table
            String[] cols = {"ID","Title","Description","Due Date","Status"};
            DefaultTableModel model = new DefaultTableModel(cols,0);
            taskTable = new JTable(model);

            JScrollPane scroll = new JScrollPane(taskTable);
            scroll.setBounds(30,110,700,180);
            panel.add(scroll);

            // 🔘 Buttons
            JButton btnAdd = new JButton("Add");
            JButton btnEdit = new JButton("Edit");
            JButton btnDelete = new JButton("Delete");
            JButton btnBack = new JButton("Back");

            btnAdd.setBounds(30,310,120,40);
            btnEdit.setBounds(180,310,120,40);
            btnDelete.setBounds(330,310,120,40);
            btnBack.setBounds(480,310,120,40);

            panel.add(btnAdd);
            panel.add(btnEdit);
            panel.add(btnDelete);
            panel.add(btnBack);

            // 🔄 Actions
            btnSearch.addActionListener(e -> loadTasks());

            btnAdd.addActionListener(e ->
                    new AddTaskForm(currentUser,this).setVisible(true)
            );

            btnEdit.addActionListener(e -> {
                int row = taskTable.getSelectedRow();
                if(row == -1){
                    JOptionPane.showMessageDialog(this,"Select a task!");
                    return;
                }

                int id = (int) taskTable.getValueAt(row,0);
                String t = taskTable.getValueAt(row,1).toString();
                String d = taskTable.getValueAt(row,2).toString();
                String date = taskTable.getValueAt(row,3).toString();
                String status = taskTable.getValueAt(row,4).toString();

                new EditTaskForm(currentUser,this,id,t,d,date,status).setVisible(true);
            });

            btnDelete.addActionListener(e -> deleteTask());
            btnBack.addActionListener(e -> dispose());

            // 🔥 Load + Reminder
            loadTasks();
            checkReminders();

            // ⏱ Auto reminder every 1 minute
            Timer timer = new Timer(60000, e -> checkReminders());
            timer.start();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    // 🔄 LOAD TASKS
    public void loadTasks(){
        try{
            Connection con = DBConnection.getConnection();

            String sql = "SELECT * FROM tasks WHERE user_id=? AND (task_title LIKE ? OR description LIKE ?)";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1,currentUser.getUserId());

            String key = "%" + txtSearch.getText().trim() + "%";
            ps.setString(2,key);
            ps.setString(3,key);

            ResultSet rs = ps.executeQuery();

            DefaultTableModel model = (DefaultTableModel) taskTable.getModel();
            model.setRowCount(0);

            while(rs.next()){
                model.addRow(new Object[]{
                        rs.getInt("task_id"),
                        rs.getString("task_title"),
                        rs.getString("description"),
                        rs.getString("due_date"),
                        rs.getString("status")
                });
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    // 🔔 REMINDER SYSTEM
    public void checkReminders(){
        try{
            Connection con = DBConnection.getConnection();

            String sql = "SELECT task_title, due_date FROM tasks WHERE user_id=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, currentUser.getUserId());

            ResultSet rs = ps.executeQuery();

            StringBuilder msg = new StringBuilder();

            while(rs.next()){
                String title = rs.getString("task_title");
                Date dueDate = rs.getDate("due_date");

                long diff = dueDate.getTime() - new Date().getTime();
                long days = diff / (1000 * 60 * 60 * 24);

                if(days == 0){
                    msg.append("🔔 Today: ").append(title).append("\n");
                } else if(days == 1){
                    msg.append("⏰ Tomorrow: ").append(title).append("\n");
                }
            }

            if(msg.length() > 0){
                JOptionPane.showMessageDialog(this, msg.toString(),
                        "Task Reminder", JOptionPane.INFORMATION_MESSAGE);
            }

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    // 🗑 DELETE
    private void deleteTask(){
        int row = taskTable.getSelectedRow();

        if(row == -1){
            JOptionPane.showMessageDialog(this,"Select a task!");
            return;
        }

        int id = (int) taskTable.getValueAt(row,0);

        try{
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("DELETE FROM tasks WHERE task_id=?");
            ps.setInt(1,id);
            ps.executeUpdate();

            JOptionPane.showMessageDialog(this,"Deleted!");
            loadTasks();

        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void refreshTable(){
        loadTasks();
    }
}